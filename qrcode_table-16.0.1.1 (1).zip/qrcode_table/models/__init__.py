# -*- coding: utf-8 -*-

from . import qrcode_table
from . import res_config_settings
